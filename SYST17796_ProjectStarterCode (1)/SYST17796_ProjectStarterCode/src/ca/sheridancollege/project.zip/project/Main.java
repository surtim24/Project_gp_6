/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ca.sheridancollege.project;

/**
 *
 * @author manav
 */
public class Main {
    public static void main(String[] args) {
        BlackJackGame game = new BlackJackGame("BJ");

        // Add players to the game
        
        game.play();
                
    }
}
